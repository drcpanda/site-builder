jQuery(document).ready(function($) {
    // Blood type genetic data
    const bloodGroups = {
        alleles: {
            A: { dominatesOver: ['O'] },
            B: { dominatesOver: ['O'] },
            O: { dominatesOver: [] }
        },
        rhesus: {
            positive: { dominatesOver: ['negative'] },
            negative: { dominatesOver: [] }
        }
    };

    // Possible genotypes for each phenotype
    const phenotypeToGenotype = {
        'A+': [['A', 'A', '+', '+'], ['A', 'A', '+', '-'], ['A', 'O', '+', '+'], ['A', 'O', '+', '-']],
        'A-': [['A', 'A', '-', '-'], ['A', 'O', '-', '-']],
        'B+': [['B', 'B', '+', '+'], ['B', 'B', '+', '-'], ['B', 'O', '+', '+'], ['B', 'O', '+', '-']],
        'B-': [['B', 'B', '-', '-'], ['B', 'O', '-', '-']],
        'AB+': [['A', 'B', '+', '+'], ['A', 'B', '+', '-']],
        'AB-': [['A', 'B', '-', '-']],
        'O+': [['O', 'O', '+', '+'], ['O', 'O', '+', '-']],
        'O-': [['O', 'O', '-', '-']]
    };

    // Regional distribution data (approximate values based on WHO data)
    const regionalData = {
        'global': {
            'O+': 37.4, 'A+': 35.7, 'B+': 8.5, 'AB+': 3.4,
            'O-': 6.6, 'A-': 6.3, 'B-': 1.5, 'AB-': 0.6
        },
        'europe': {
            'O+': 35, 'A+': 38, 'B+': 8, 'AB+': 3,
            'O-': 7, 'A-': 7, 'B-': 1.5, 'AB-': 0.5
        },
        'northamerica': {
            'O+': 38, 'A+': 34, 'B+': 9, 'AB+': 3,
            'O-': 7, 'A-': 6, 'B-': 2, 'AB-': 1
        },
        'asia': {
            'O+': 39, 'A+': 27, 'B+': 25, 'AB+': 7,
            'O-': 1, 'A-': 0.5, 'B-': 0.4, 'AB-': 0.1
        },
        'africa': {
            'O+': 47, 'A+': 24, 'B+': 21, 'AB+': 4,
            'O-': 2, 'A-': 1, 'B-': 0.7, 'AB-': 0.3
        }
    };

    // Function to get possible genotypes for a blood group
    function getPossibleGenotypes(bloodGroup) {
        return phenotypeToGenotype[bloodGroup] || [];
    }

    // Function to get possible child alleles from parent genotypes
    function getPossibleChildGenotypes(fatherGenotypes, motherGenotypes) {
        const possibleChildGenotypes = [];
        
        fatherGenotypes.forEach(fatherGenotype => {
            motherGenotypes.forEach(motherGenotype => {
                // Blood type alleles (A, B, O)
                const fatherAlleles = [fatherGenotype[0], fatherGenotype[1]];
                const motherAlleles = [motherGenotype[0], motherGenotype[1]];
                
                // Rhesus alleles (+, -)
                const fatherRhesus = [fatherGenotype[2], fatherGenotype[3]];
                const motherRhesus = [motherGenotype[2], motherGenotype[3]];
                
                // Generate all possible combinations
                for (let i = 0; i < 2; i++) {
                    for (let j = 0; j < 2; j++) {
                        for (let k = 0; k < 2; k++) {
                            for (let l = 0; l < 2; l++) {
                                possibleChildGenotypes.push([
                                    fatherAlleles[i],
                                    motherAlleles[j],
                                    fatherRhesus[k],
                                    motherRhesus[l]
                                ]);
                            }
                        }
                    }
                }
            });
        });
        
        return possibleChildGenotypes;
    }

    // Function to convert genotype to phenotype
    function genotypeToPhenotype(genotype) {
        // Sort ABO alleles by dominance
        const aboAlleles = [genotype[0], genotype[1]].sort((a, b) => {
            if (a === b) return 0;
            if (a === 'A' && b === 'O') return -1;
            if (a === 'B' && b === 'O') return -1;
            if (a === 'A' && b === 'B') return -1;
            if (a === 'B' && b === 'A') return 1;
            return 0;
        });
        
        // Determine blood group
        let bloodType;
        if (aboAlleles.includes('A') && aboAlleles.includes('B')) {
            bloodType = 'AB';
        } else if (aboAlleles.includes('A')) {
            bloodType = 'A';
        } else if (aboAlleles.includes('B')) {
            bloodType = 'B';
        } else {
            bloodType = 'O';
        }
        
        // Determine Rhesus factor
        const rhesusAlleles = [genotype[2], genotype[3]];
        const rhesus = rhesusAlleles.includes('+') ? '+' : '-';
        
        return bloodType + rhesus;
    }

    // Function to get CSS class for blood group
    function getBloodGroupClass(bloodGroup) {
        const bloodType = bloodGroup.charAt(0) + (bloodGroup.length > 2 ? bloodGroup.charAt(1) : '');
        const rhesus = bloodGroup.includes('+') ? 'positive' : 'negative';
        return `blood-group-${bloodType}-${rhesus}`;
    }

    // Function to calculate possible blood groups
    function calculatePossibleBloodGroups() {
        const fatherBloodGroup = $('#father-blood-group').val();
        const motherBloodGroup = $('#mother-blood-group').val();
        
        // Check if both parents' blood groups are provided
        if (!fatherBloodGroup || !motherBloodGroup) {
            alert('Please select blood groups for both parents.');
            return;
        }
        
        // Get possible genotypes for parents
        const fatherGenotypes = getPossibleGenotypes(fatherBloodGroup);
        const motherGenotypes = getPossibleGenotypes(motherBloodGroup);
        
        // Get possible child genotypes
        const childGenotypes = getPossibleChildGenotypes(fatherGenotypes, motherGenotypes);
        
        // Convert genotypes to phenotypes and count frequencies
        const phenotypeCount = {};
        childGenotypes.forEach(genotype => {
            const phenotype = genotypeToPhenotype(genotype);
            phenotypeCount[phenotype] = (phenotypeCount[phenotype] || 0) + 1;
        });
        
        // Calculate probabilities
        const totalCombinations = childGenotypes.length;
        const results = {};
        
        for (const [phenotype, count] of Object.entries(phenotypeCount)) {
            results[phenotype] = (count / totalCombinations) * 100;
        }
        
        displayResults(results);
    }

    // Function to display results
    function displayResults(results) {
        const resultsContainer = $('#results-container');
        const possibleBloodGroups = $('#possible-blood-groups');
        const regionalInfo = $('#regional-info');
        
        // Clear previous results
        possibleBloodGroups.empty();
        regionalInfo.empty();
        
        // Create HTML for results
        let resultHTML = '<h4>POSSIBLE BLOOD GROUPS:</h4><ul>';
        
        // Sort results by probability (highest first)
        const sortedResults = Object.entries(results).sort((a, b) => b[1] - a[1]);
        
        sortedResults.forEach(([bloodGroup, probability]) => {
            const bloodGroupClass = getBloodGroupClass(bloodGroup);
            resultHTML += `<li class="${bloodGroupClass}"><strong>${bloodGroup}</strong>: ${probability.toFixed(2)}%</li>`;
        });
        
        resultHTML += '</ul>';
        
        // Add color legend
        resultHTML += '<div class="blood-group-legend">';
        resultHTML += '<div class="legend-title">Blood Group Legend:</div>';
        
        const allBloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
        allBloodGroups.forEach(bloodGroup => {
            const bloodGroupClass = getBloodGroupClass(bloodGroup);
            resultHTML += `
                <div class="legend-item">
                    <div class="legend-color ${bloodGroupClass}"></div>
                    <div>${bloodGroup}</div>
                </div>
            `;
        });
        
        resultHTML += '</div>';
        
        possibleBloodGroups.html(resultHTML);
        
        // Display regional information if selected
        const selectedRegion = $('#region').val();
        if (selectedRegion) {
            const regionData = regionalData[selectedRegion] || regionalData['global'];
            let regionHTML = `<h4>Regional Distribution (${selectedRegion.charAt(0).toUpperCase() + selectedRegion.slice(1)}):</h4><ul>`;
            
            Object.entries(regionData).sort((a, b) => b[1] - a[1]).forEach(([bloodGroup, percentage]) => {
                const isChild = Object.keys(results).includes(bloodGroup);
                const bloodGroupClass = getBloodGroupClass(bloodGroup);
                regionHTML += `<li class="${bloodGroupClass}${isChild ? ' highlight' : ''}">${bloodGroup}: ${percentage}%${isChild ? ' (possible child blood group)' : ''}</li>`;
            });
            
            regionHTML += '</ul>';
            regionalInfo.html(regionHTML);
        }
        
        // Show results container
        resultsContainer.show();
    }

    // Event listener for calculate button
    $('#calculate-blood-group').on('click', calculatePossibleBloodGroups);
});