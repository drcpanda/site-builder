<?php
/**
 * Plugin Name: Blood Group Calculator
 * Description: Calculates possible blood groups of a baby based on parents and grandparents
 * Version: 1.0
 * Author: drcpanda
 */

// Shortcode for the blood group calculator
function blood_group_calculator_shortcode() {
    ob_start();
    ?>
    <div id="blood-group-calculator">
        <h2>Blood Group Inheritance Calculator</h2>
        
        <div class="parents-section">
            <h3>Parents Blood Groups</h3>
            <div class="form-row">
                <div class="form-group">
                    <label for="father-blood-group">Father's Blood Group:</label>
                    <select id="father-blood-group" class="blood-group-select">
                        <option value="">Select</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="mother-blood-group">Mother's Blood Group:</label>
                    <select id="mother-blood-group" class="blood-group-select">
                        <option value="">Select</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="grandparents-section">
            <h3>Grandparents Blood Groups (Optional)</h3>
            <div class="form-row">
                <div class="form-group">
                    <label for="paternal-grandfather">Paternal Grandfather:</label>
                    <select id="paternal-grandfather" class="blood-group-select">
                        <option value="">Unknown/Not Provided</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="paternal-grandmother">Paternal Grandmother:</label>
                    <select id="paternal-grandmother" class="blood-group-select">
                        <option value="">Unknown/Not Provided</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="maternal-grandfather">Maternal Grandfather:</label>
                    <select id="maternal-grandfather" class="blood-group-select">
                        <option value="">Unknown/Not Provided</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="maternal-grandmother">Maternal Grandmother:</label>
                    <select id="maternal-grandmother" class="blood-group-select">
                        <option value="">Unknown/Not Provided</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="region-section">
            <h3>Regional Data (Optional)</h3>
            <div class="form-group">
                <label for="region">Region:</label>
                <select id="region">
                    <option value="">Global Average</option>
                    <option value="europe">Europe</option>
                    <option value="northamerica">North America</option>
                    <option value="asia">Asia</option>
                    <option value="africa">Africa</option>
                </select>
            </div>
        </div>

        <button id="calculate-blood-group" class="calculate-button">Calculate Possible Blood Groups</button>

        <div id="results-container" style="display: none;">
            <h3>Results</h3>
            <div id="results-box">
                <div id="possible-blood-groups"></div>
                <div id="probability-chart"></div>
                <div id="regional-info"></div>
            </div>
            <div id="disclaimer">
                <p><strong>Disclaimer:</strong> This tool provides theoretical possibilities based on genetic inheritance patterns. For medical decisions, please consult with healthcare professionals or genetic counselors.</p>
            </div>
        </div>
    </div>
    <?php
    wp_enqueue_style('blood-group-calculator-css', plugin_dir_url(__FILE__) . 'blood-group-calculator.css');
    wp_enqueue_script('blood-group-calculator-js', plugin_dir_url(__FILE__) . 'blood-group-calculator.js', array('jquery'), '1.0', true);
    
    return ob_get_clean();
}
add_shortcode('blood_group_calculator', 'blood_group_calculator_shortcode');
?>